Imports System

Public Module MyProgram
    Sub Main
        Dim nama As String, jeniskelamin As String
        Dim usia As Integer, tdeeInt As Integer
        Dim berat As Double, tinggi As Double, bmrL As Double, bmrP As Double, tdeeKH As Double, fAKTORAKTIVITAS As Double

        fAKTORAKTIVITAS = 1.375
        Console.WriteLine("silahkan masukkan nama anda")
        nama = Console.ReadLine()
        Console.WriteLine("Silahkan masukkan jeniskelamin")
        jeniskelamin = Console.ReadLine()
        Console.WriteLine("Silahkan masukkan usia anda")
        usia = inputValue()
        Console.WriteLine("Silahkan masukkan berat anda")
        berat = inputValue()
        Console.WriteLine("Silahkan masukkan tinggi anda")
        tinggi = inputValue()
        If jeniskelamin = "P" Then
            bmrP = 10 * berat + 6.25 * tinggi - 5 * usia - 161
            Console.WriteLine(bmrP)
            tdeeKH = bmrP * fAKTORAKTIVITAS
            Console.WriteLine("TDEE kalori harian anda :" & tdeeKH)
        Else
            bmrL = 10 * berat + 6.25 * tinggi - 5 * usia + 5
            Console.WriteLine(bmrL)
            tdeeKH = bmrL * fAKTORAKTIVITAS
            Console.WriteLine("TDEE kalori harian anda :" & tdeeKH)
        End If
        tdeeInt = tdeeKH
        Console.WriteLine("Casting TDEE :" & tdeeInt)
    End Sub
    
    ' .NET can only read single characters or entire lines from the console.
    ' The following function safely reads a double value.
    Private Function inputValue() As Double
        Dim result As Double
        While Not Double.TryParse(Console.ReadLine(), result)
            ' No code in the loop
        End While
        Return result
    End Function
End Module
