Imports System

Public Module MyProgram
    Sub Main
        Dim uang As Integer, seratusribu As Integer, limapuluhribu As Integer, duapuluhribu As Integer, sepuluhribu As Integer, limaribu As Integer, duaribu As Integer, seribu As Integer, koinreceh As Integer

        Console.WriteLine("Masukkan jumlah uang")
        uang = inputValue()
        seratusribu = uang / 100000
        uang = uang Mod 100000
        limapuluhribu = uang / 50000
        uang = uang Mod 50000
        duapuluhribu = uang / 20000
        uang = uang Mod 20000
        sepuluhribu = uang / 10000
        uang = uang Mod 10000
        limaribu = uang / 5000
        uang = uang Mod 5000
        duaribu = uang / 2000
        uang = uang Mod 2000
        seribu = uang / 1000
        uang = uang Mod 1000
        koinreceh = uang / 500
        koinreceh = uang
        Console.WriteLine("Pecahan 100.000:" & seratusribu & ", Pecahan 50.000:" & limapuluhribu & ", Pecahan 20.000:" & duapuluhribu & ", Pecahan 10.000:" & sepuluhribu & ", Pecahan 5.000:" & limaribu & ", Pecahan 2.000:" & duaribu & ", Pecahan 1.000:" & seribu & ", koinreceh:" & uang)
    End Sub
    
    ' .NET can only read single characters or entire lines from the console.
    ' The following function safely reads a double value.
    Private Function inputValue() As Double
        Dim result As Double
        While Not Double.TryParse(Console.ReadLine(), result)
            ' No code in the loop
        End While
        Return result
    End Function
End Module
