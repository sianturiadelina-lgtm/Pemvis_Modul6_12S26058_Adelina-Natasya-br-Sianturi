Imports System

Public Module MyProgram
    Sub Main
        Dim sF As Boolean, sK As Boolean, sRJ As Boolean, terdaftarBlacklist As Boolean
        Dim penghasilan As Integer, lamaUsaha As Integer, skorKredit As Integer, angsuran As Integer, nilaiAgunan As Integer
        Dim agunan As Double, biayaAdministrasi As Double, totalPinjaman As Double

        Console.WriteLine("Masukkan terdaftarBlacklist")
        terdaftarBlacklist = inputValue()
        Console.WriteLine("Masukkan Penghasilan")
        penghasilan = inputValue()
        Console.WriteLine("Masukkan lamaUsaha")
        lamaUsaha = inputValue()
        Console.WriteLine("Masukkan skorKredit")
        skorKredit = inputValue()
        Console.WriteLine("Masukkan agunan")
        nilaiAgunan = inputValue()
        Console.WriteLine("Masukkan totalPinjaman")
        totalPinjaman = inputValue()
        sF = penghasilan >= 5000000 Or nilaiAgunan >= 1.5
        sRJ = skorKredit >= 70 And lamaUsaha >= 2
        sK = sF And sRJ And Not terdaftarBlacklist
        If sK = sF And sRJ And Not terdaftarBlacklist Then
            totalPinjaman = totalPinjaman + totalPinjaman * 0.025
            angsuran = totalPinjaman / 12
            Console.WriteLine("Pinjaman diterima")
        Else
            Console.WriteLine("Pinjaman ditolak")
        End If
    End Sub
    
    ' .NET can only read single characters or entire lines from the console.
    ' The following function safely reads a double value.
    Private Function inputValue() As Double
        Dim result As Double
        While Not Double.TryParse(Console.ReadLine(), result)
            ' No code in the loop
        End While
        Return result
    End Function
End Module
