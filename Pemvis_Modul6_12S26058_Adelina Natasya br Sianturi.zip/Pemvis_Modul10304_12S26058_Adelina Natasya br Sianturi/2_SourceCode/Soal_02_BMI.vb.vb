Imports System

Public Module MyProgram
    Sub Main
        Dim usia As Integer
        Dim gizi As String
        Dim bMI As Double, berat As Double, tinggi As Double

        Console.WriteLine("Masukkan usia anda")
        usia = inputValue()
        Console.WriteLine("Masukkan berat badan anda")
        berat = inputValue()
        Console.WriteLine("Masukkan tinggi anda")
        tinggi = inputValue()
        bMI = berat / tinggi ^ 2
        Console.WriteLine("BMI :" & bMI)
        If bMI < 18.5 Then
            Console.WriteLine("Underweight")
        Else
            If bMI < 25.0 Then
                Console.WriteLine("Normal")
            Else
                If bMI < 30.0 Then
                    Console.WriteLine("Overweight")
                Else
                    If bMI >= 30.0 Then
                        Console.WriteLine("Obesitas")
                    End If
                End If
            End If
        End If
        If bMI >= 18.5 And bMI <= 24.9 And usia >= 18 And usia <= 60 Then
            Console.WriteLine("Ideal? true")
        Else
            Console.WriteLine("Ideal ? false")
        End If
    End Sub
    
    ' .NET can only read single characters or entire lines from the console.
    ' The following function safely reads a double value.
    Private Function inputValue() As Double
        Dim result As Double
        While Not Double.TryParse(Console.ReadLine(), result)
            ' No code in the loop
        End While
        Return result
    End Function
End Module
